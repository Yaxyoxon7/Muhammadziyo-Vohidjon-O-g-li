# Muhammadziyo Vohidjon o‘g‘li — muallif sayti

React + Vite + TypeScript asosidagi responsive, qora-oltin dizayndagi muallif sayti.

## 1. Ishga tushirish
```bash
npm install
npm run dev
```

## 2. Haqiqiy rasmlarni qo‘shish
`public/images/` papkasiga quyidagi nomlar bilan rasmlarni joylashtiring:
- `muhammadziyo.jpg` — muallif portreti
- `kim-jannatni-istasa.jpg`
- `olimlarning-ayollari.jpg`
- `olim-yetishtirgan-onalar.jpg`
- `fotima-toyi.jpg`

Rasmlar topilmaguncha sahifa placeholder ko‘rsatadi.

## 3. Instagram Reels
Saytdagi “Reel link qo‘shish” orqali Instagram havolasini kiritish mumkin. Bu hozir demo holat: sahifa yangilanganda kiritilgan linklar yo‘qoladi. Doimiy saqlash uchun backend yoki ma’lumotlar bazasi ulang. Instagram videolari embed bo‘lmasligi mumkin; shu sababli havolalar original Instagram sahifasiga olib boradi.

## Eslatma
Iqtiboslar hozircha dizayn namunasi, muallifning tasdiqlangan so‘zlari deb ko‘rsatilmasin. Tasdiqlangan iqtiboslar bilan almashtiring. Tarjimai holga faqat tekshirilgan ma’lumotlarni qo‘shing.
