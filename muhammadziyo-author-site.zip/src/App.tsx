import { useMemo, useState } from "react";
import {
  BookOpen, Instagram, PlayCircle, Quote, Menu, X, ArrowUpRight,
  ChevronDown, UserRound, Sparkles, ExternalLink
} from "lucide-react";
import "./styles.css";

type Book = { title: string; description: string; image: string; label: string };

const books: Book[] = [
  {
    title: "Kim jannatni istasa…",
    description: "Imom Abu Homid G‘azzoliy asari asosidagi ma’naviy-ruhiy mulohazalar.",
    image: "/images/kim-jannatni-istasa.jpg",
    label: "Ma’naviyat"
  },
  {
    title: "Olimlarning ayollari",
    description: "Ilm ahlining oilalari va olima, solih ayollar hayotidan lavhalar.",
    image: "/images/olimlarning-ayollari.jpg",
    label: "Tarixiy"
  },
  {
    title: "Olim yetishtirgan onalar",
    description: "Buyuk olimlar kamolida onalarning o‘rni haqida.",
    image: "/images/olim-yetishtirgan-onalar.jpg",
    label: "Tarbiya"
  },
  {
    title: "Fotima roziyallohu anhuning isrofsiz to‘yi",
    description: "Soddalik, baraka va oilaviy qadriyatlar haqida.",
    image: "/images/fotima-toyi.jpg",
    label: "Oila"
  }
];

const quotes = [
  "Ilm — insonni yaxshilik sari yetaklaydigan yo‘l.",
  "Go‘zal tarbiya avvalo oiladan boshlanadi.",
  "Soddalikda ham baraka, ma’noda ham go‘zallik bor."
];

const authorInstagram = "https://www.instagram.com/muhammad_vahiyd/";
const booknote = "https://booknote.uz/author/muhammad-ziyo-vohidjon-ogli";

function ImageOrPlaceholder({ src, alt, className = "" }: { src: string; alt: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return <div className={`image-placeholder ${className}`}><BookOpen size={34} /><span>Haqiqiy rasmni shu yerga qo‘shing</span></div>;
  }
  return <img className={className} src={src} alt={alt} onError={() => setFailed(true)} />;
}

function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeBook, setActiveBook] = useState<Book | null>(null);
  const [reelLinks, setReelLinks] = useState<string[]>([""]);
  const [newReel, setNewReel] = useState("");
  const [showReelEditor, setShowReelEditor] = useState(false);
  const validReels = useMemo(() => reelLinks.filter((link) => /^https:\/\/(www\.)?instagram\.com\/(reel|p)\//.test(link.trim())), [reelLinks]);

  const navItems = [
    ["Muallif haqida", "#muallif"],
    ["Kitoblar", "#kitoblar"],
    ["Iqtiboslar", "#iqtiboslar"],
    ["Videolar", "#videolar"],
    ["Bog‘lanish", "#aloqa"]
  ];

  return (
    <div className="site-shell">
      <header className="site-header">
        <a href="#top" className="brand"><span className="brand-mark">M</span><span>MUHAMMADZIYO <small>VOHIDJON O‘G‘LI</small></span></a>
        <button className="mobile-menu" aria-label="Menyuni ochish" onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X /> : <Menu />}</button>
        <nav className={mobileOpen ? "nav-links open" : "nav-links"}>
          {navItems.map(([label, href]) => <a key={href} href={href} onClick={() => setMobileOpen(false)}>{label}</a>)}
        </nav>
        <a className="header-cta" href={authorInstagram} target="_blank" rel="noreferrer">Instagram <ArrowUpRight size={15} /></a>
      </header>

      <main id="top">
        <section className="hero section-wrap">
          <div className="hero-copy">
            <div className="eyebrow"><Sparkles size={15} /> MUALLIFNING IJODIY SAHIFASI</div>
            <h1>Ilm va ma’rifat<br /><em>sari bir safar.</em></h1>
            <p className="hero-lead">Muhammadziyo Vohidjon o‘g‘li — islomiy adabiyot, mutolaa va ma’naviy merosga bag‘ishlangan ijodiy sahifa.</p>
            <div className="hero-actions">
              <a className="button button-gold" href="#kitoblar">Kitoblarni ko‘rish <ArrowUpRight size={17} /></a>
              <a className="button button-ghost" href="#muallif">Muallif haqida</a>
            </div>
            <div className="hero-note"><span className="note-line" /> Ilmdan o‘zga najot yo‘q!</div>
          </div>
          <div className="hero-visual">
            <div className="portrait-frame">
              <ImageOrPlaceholder src="/images/muhammadziyo.jpg" alt="Muhammadziyo Vohidjon o‘g‘li portreti" className="portrait-image" />
              <div className="portrait-caption"><span>MUALLIF</span><strong>Muhammadziyo Vohidjon o‘g‘li</strong></div>
            </div>
            <div className="orbit orbit-one" /><div className="orbit orbit-two" />
            <div className="hero-stamp"><BookOpen size={23} /><span>Mutolaa<br />va ma’rifat</span></div>
          </div>
        </section>

        <section id="muallif" className="about-section section-wrap">
          <div className="section-kicker">01 / MUALLIF</div>
          <div className="about-grid">
            <div>
              <h2>So‘z orqali <em>ma’rifat.</em></h2>
              <p className="large-copy">Kitob — tafakkurga ochilgan eshik, mutolaa esa qalbni boyitadigan safar.</p>
            </div>
            <div className="about-text">
              <p>Muhammadziyo Vohidjon o‘g‘li o‘zbek tilidagi islomiy adabiyot va tarjima ishlari bilan bog‘liq muallif sifatida tanilgan. Uning ijodiy sahifasida kitoblar, ma’rifiy fikrlar va videolar jamlanadi.</p>
              <p>Bu bo‘limga muallifning tasdiqlangan tarjimai holi, faoliyati va yutuqlarini keyinchalik aniq ma’lumotlar asosida qo‘shish mumkin.</p>
              <a className="text-link" href={booknote} target="_blank" rel="noreferrer">BookNote sahifasi <ArrowUpRight size={16} /></a>
            </div>
          </div>
        </section>

        <section id="kitoblar" className="books-section">
          <div className="section-wrap">
            <div className="section-heading">
              <div><div className="section-kicker">02 / ASARLAR</div><h2>Kitoblar <em>to‘plami</em></h2></div>
              <p>Muqovani tanlang — kitob haqida qisqacha ma’lumotni ko‘ring.</p>
            </div>
            <div className="books-grid">
              {books.map((book, index) => (
                <button className="book-card" key={book.title} onClick={() => setActiveBook(book)}>
                  <div className="book-cover-wrap">
                    <ImageOrPlaceholder src={book.image} alt={book.title + " muqovasi"} className="book-cover" />
                    <span className="book-index">0{index + 1}</span>
                    <span className="book-open"><ArrowUpRight size={19} /></span>
                  </div>
                  <div className="book-info"><span className="book-label">{book.label}</span><h3>{book.title}</h3><p>{book.description}</p></div>
                </button>
              ))}
            </div>
          </div>
        </section>

        <section id="iqtiboslar" className="quotes-section section-wrap">
          <div className="section-kicker">03 / HIKMATLI SO‘ZLAR</div>
          <div className="quotes-heading"><Quote size={30} /><h2>Fikrga chorlovchi <em>so‘zlar.</em></h2></div>
          <div className="quotes-grid">
            {quotes.map((quote, i) => <article className="quote-card" key={quote}><span>“</span><p>{quote}</p><small>0{i + 1}</small></article>)}
          </div>
          <p className="disclaimer">Eslatma: bu uch jumla hozircha dizayn namunasi; muallifning aynan o‘z iqtiboslari deb taqdim etilmasin. Tasdiqlangan iqtiboslar bilan almashtiring.</p>
        </section>

        <section id="videolar" className="video-section">
          <div className="section-wrap">
            <div className="section-heading">
              <div><div className="section-kicker">04 / VIDEO</div><h2>Kitoblar <em>harakatda.</em></h2></div>
              <button className="button button-ghost" onClick={() => setShowReelEditor(!showReelEditor)}>{showReelEditor ? "Yopish" : "Reel link qo‘shish"} <ChevronDown size={16} /></button>
            </div>
            <p className="video-intro">Instagram Reels videolarini shu yerga bog‘lang. Instagram embed hamma holatda ishlamasligi mumkin, shuning uchun har bir video original havola orqali ham ochiladi.</p>
            {showReelEditor && <div className="reel-editor">
              <label htmlFor="reel-url">Instagram Reel havolasi</label>
              <div className="reel-input-row"><input id="reel-url" value={newReel} onChange={(e) => setNewReel(e.target.value)} placeholder="https://www.instagram.com/reel/..." /><button className="button button-gold" onClick={() => { if (/^https:\/\/(www\.)?instagram\.com\/(reel|p)\//.test(newReel.trim())) { setReelLinks((old) => [...old.filter(Boolean), newReel.trim()]); setNewReel(""); } }}>Qo‘shish</button></div>
              <small>Bu demo shakl: kiritilgan havolalar hozircha faqat sahifa ochiq turgan paytda saqlanadi. Doimiy saqlash uchun ma’lumotlar bazasi kerak.</small>
            </div>}
            <div className="reels-grid">
              {validReels.length ? validReels.map((link, i) => <a className="reel-card" key={link + i} href={link} target="_blank" rel="noreferrer"><div className="reel-preview"><PlayCircle size={44} /><span>INSTAGRAM REEL</span></div><div className="reel-card-bottom"><span>Kitob videosi {i + 1}</span><ExternalLink size={16} /></div></a>) : <div className="video-empty"><PlayCircle size={42} /><h3>Videolar shu yerda ko‘rinadi</h3><p>“Reel link qo‘shish” tugmasini bosing yoki koddagi Instagram havolalarini kiriting.</p></div>}
            </div>
          </div>
        </section>

        <section className="closing-quote section-wrap"><span className="closing-mark">“</span><p>Mutolaa — qalb va tafakkur uchun sayohat.</p><span className="closing-rule" /></section>
      </main>

      <footer id="aloqa" className="site-footer">
        <div className="section-wrap footer-inner">
          <div><a href="#top" className="brand footer-brand"><span className="brand-mark">M</span><span>MUHAMMADZIYO <small>VOHIDJON O‘G‘LI</small></span></a><p>Ilm, kitob va ma’rifatga bag‘ishlangan sahifa.</p></div>
          <div className="footer-links"><a href={authorInstagram} target="_blank" rel="noreferrer"><Instagram size={17} /> Instagram <ArrowUpRight size={14} /></a><a href={booknote} target="_blank" rel="noreferrer"><BookOpen size={17} /> BookNote <ArrowUpRight size={14} /></a></div>
          <div className="footer-bottom"><span>© {new Date().getFullYear()} Muhammadziyo Vohidjon o‘g‘li</span><a href="#top">Yuqoriga ↑</a></div>
        </div>
      </footer>

      {activeBook && <div className="modal-backdrop" role="presentation" onClick={() => setActiveBook(null)}><div className="book-modal" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}><button className="modal-close" onClick={() => setActiveBook(null)} aria-label="Yopish"><X /></button><ImageOrPlaceholder src={activeBook.image} alt={activeBook.title} className="modal-cover" /><div><span className="book-label">{activeBook.label}</span><h2>{activeBook.title}</h2><p>{activeBook.description}</p><a className="text-link" href={booknote} target="_blank" rel="noreferrer">BookNote’da ko‘rish <ArrowUpRight size={16} /></a></div></div></div>}
    </div>
  );
}

export default App;
